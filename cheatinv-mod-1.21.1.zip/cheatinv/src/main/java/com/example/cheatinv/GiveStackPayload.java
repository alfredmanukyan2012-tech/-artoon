package com.example.cheatinv;

import net.minecraft.item.ItemStack;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Клиент просит выдать готовый стак (с зачарованиями и прочими компонентами). */
public record GiveStackPayload(ItemStack stack) implements CustomPayload {
    public static final CustomPayload.Id<GiveStackPayload> ID =
            new CustomPayload.Id<>(Identifier.of("cheatinv", "give_stack"));

    public static final PacketCodec<RegistryByteBuf, GiveStackPayload> CODEC = PacketCodec.tuple(
            ItemStack.PACKET_CODEC, GiveStackPayload::stack,
            GiveStackPayload::new
    );

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
