package com.example.cheatinv;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class ItemMenuScreen extends Screen {
    private static final int COLS = 10;
    private static final int ROWS = 6;
    private static final int SLOT = 18;
    private static final int ENCH_W = 140;
    private static final int GAP = 8;
    private static final int ROW_H = 12;
    private static final int TAB_W = 24;
    private static final int TAB_H = 22;

    // Хранятся между открытиями меню
    private static String lastSearch = "";
    private static int lastTab = 0;
    private static final Map<Identifier, Integer> enchLevels = new LinkedHashMap<>();

    private record Tab(Text name, ItemStack icon, List<ItemStack> stacks) {}
    private record Ench(Identifier id, Text name, int max) {}

    private final List<Tab> tabs = new ArrayList<>();
    private final List<Ench> enchants = new ArrayList<>();
    private final List<ItemStack> filtered = new ArrayList<>();

    private TextFieldWidget search;
    private int currentTab = 0;
    private int scrollRow = 0;
    private int enchScroll = 0;

    // раскладка
    private int left, topY, tabsY, searchY, gridY, enchX, tabsPerRow, tabRows;

    public ItemMenuScreen() {
        super(Text.translatable("cheatinv.title"));
    }

    private void loadData() {
        var world = client.world;
        if (world == null) return;

        // Все предметы
        List<ItemStack> allStacks = new ArrayList<>();
        for (Item item : Registries.ITEM) {
            if (item != Items.AIR) allStacks.add(new ItemStack(item));
        }
        tabs.add(new Tab(Text.translatable("cheatinv.tab.all"), new ItemStack(Items.NETHER_STAR), allStacks));

        // Вкладки как в творческом режиме. true = показывать и служебные предметы
        // (командный блок, барьер и т.д.)
        ItemGroups.updateDisplayContext(world.getEnabledFeatures(), true, world.getRegistryManager());
        ItemGroup op = Registries.ITEM_GROUP.get(ItemGroups.OPERATOR);
        for (ItemGroup g : Registries.ITEM_GROUP) {
            if (g.getType() != ItemGroup.Type.CATEGORY) continue;
            var ds = g.getDisplayStacks();
            if (ds.isEmpty()) continue;
            Text name = (g == op) ? Text.translatable("cheatinv.tab.operator") : g.getDisplayName();
            tabs.add(new Tab(name, g.getIcon(), new ArrayList<>(ds)));
        }

        // Зачарования
        var reg = world.getRegistryManager().get(RegistryKeys.ENCHANTMENT);
        reg.streamEntries().forEach(ref -> enchants.add(
                new Ench(ref.registryKey().getValue(), ref.value().description(), ref.value().getMaxLevel())));
        enchants.sort(Comparator.comparing(e -> e.name().getString()));
    }

    @Override
    protected void init() {
        if (tabs.isEmpty()) loadData();
        currentTab = Math.max(0, Math.min(lastTab, tabs.size() - 1));

        int totalW = COLS * SLOT + GAP + ENCH_W;
        left = (width - totalW) / 2;
        tabsPerRow = Math.max(1, totalW / TAB_W);
        tabRows = Math.max(1, (tabs.size() + tabsPerRow - 1) / tabsPerRow);

        int totalH = tabRows * TAB_H + 4 + 20 + ROWS * SLOT + 30;
        topY = Math.max(6, (height - totalH) / 2);
        tabsY = topY;
        searchY = tabsY + tabRows * TAB_H + 4;
        gridY = searchY + 20;
        enchX = left + COLS * SLOT + GAP;

        search = new TextFieldWidget(textRenderer, left, searchY, COLS * SLOT, 16, Text.translatable("cheatinv.title"));
        search.setText(lastSearch);
        search.setChangedListener(s -> {
            lastSearch = s;
            scrollRow = 0;
            applyFilter();
        });
        addDrawableChild(search);
        setInitialFocus(search);

        addDrawableChild(ButtonWidget.builder(Text.translatable("cheatinv.reset"), b -> enchLevels.clear())
                .dimensions(enchX + ENCH_W - 44, searchY - 1, 44, 18)
                .build());

        applyFilter();
    }

    private void applyFilter() {
        filtered.clear();
        if (tabs.isEmpty()) return;
        String q = search.getText().trim().toLowerCase(Locale.ROOT);
        for (ItemStack stack : tabs.get(currentTab).stacks()) {
            if (q.isEmpty()
                    || stack.getName().getString().toLowerCase(Locale.ROOT).contains(q)
                    || Registries.ITEM.getId(stack.getItem()).toString().contains(q)) {
                filtered.add(stack);
            }
        }
        scrollRow = Math.min(scrollRow, maxScroll());
    }

    private int maxScroll() {
        int totalRows = (filtered.size() + COLS - 1) / COLS;
        return Math.max(0, totalRows - ROWS);
    }

    private int visibleEnchRows() {
        return (ROWS * SLOT) / ROW_H;
    }

    private int maxEnchScroll() {
        return Math.max(0, enchants.size() - visibleEnchRows());
    }

    /** Делает копию предмета с выбранными зачарованиями и нужным количеством. */
    private ItemStack buildStack(ItemStack base, int count) {
        ItemStack s = base.copy();
        boolean hasEnchants = false;
        for (int lv : enchLevels.values()) {
            if (lv > 0) { hasEnchants = true; break; }
        }

        if (hasEnchants && client.world != null) {
            if (s.isOf(Items.BOOK)) {
                s = new ItemStack(Items.ENCHANTED_BOOK);
            }
            if (s.isOf(Items.ENCHANTED_BOOK) || s.contains(DataComponentTypes.ENCHANTABLE)) {
                var type = s.isOf(Items.ENCHANTED_BOOK)
                        ? DataComponentTypes.STORED_ENCHANTMENTS
                        : DataComponentTypes.ENCHANTMENTS;
                var reg = client.world.getRegistryManager().get(RegistryKeys.ENCHANTMENT);
                var builder = new ItemEnchantmentsComponent.Builder(
                        s.getOrDefault(type, ItemEnchantmentsComponent.DEFAULT));
                for (Map.Entry<Identifier, Integer> e : enchLevels.entrySet()) {
                    if (e.getValue() <= 0) continue;
                    int lv = e.getValue();
                    reg.getEntry(e.getKey()).ifPresent(entry -> builder.set(entry, lv));
                }
                s.set(type, builder.build());
            }
        }
        s.setCount(Math.max(1, Math.min(count, s.getMaxCount())));
        return s;
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.renderBackground(ctx, mouseX, mouseY, delta);
        int totalW = COLS * SLOT + GAP + ENCH_W;
        ctx.fill(left - 6, topY - 6, left + totalW + 6, gridY + ROWS * SLOT + 30, 0xE0101010);

        // сетка предметов
        ctx.fill(left - 1, gridY - 1, left + COLS * SLOT + 1, gridY + ROWS * SLOT + 1, 0xFF373737);
        ctx.fill(left, gridY, left + COLS * SLOT, gridY + ROWS * SLOT, 0xFF8B8B8B);

        // панель зачарований
        ctx.fill(enchX - 1, gridY - 1, enchX + ENCH_W + 1, gridY + ROWS * SLOT + 1, 0xFF373737);
        ctx.fill(enchX, gridY, enchX + ENCH_W, gridY + ROWS * SLOT, 0xFF202020);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);

        Text tabTooltip = null;

        // Вкладки
        for (int i = 0; i < tabs.size(); i++) {
            int x = left + (i % tabsPerRow) * TAB_W;
            int y = tabsY + (i / tabsPerRow) * TAB_H;
            boolean selected = i == currentTab;
            ctx.fill(x, y, x + TAB_W - 1, y + TAB_H - 1, selected ? 0xFFC6C6C6 : 0xFF4A4A4A);
            ctx.drawItem(tabs.get(i).icon(), x + 4, y + 3);
            if (mouseX >= x && mouseX < x + TAB_W - 1 && mouseY >= y && mouseY < y + TAB_H - 1) {
                tabTooltip = tabs.get(i).name();
            }
        }

        // Сетка предметов
        ItemStack hovered = null;
        for (int i = 0; i < COLS * ROWS; i++) {
            int idx = scrollRow * COLS + i;
            if (idx >= filtered.size()) break;

            int x = left + (i % COLS) * SLOT;
            int y = gridY + (i / COLS) * SLOT;
            ItemStack stack = filtered.get(idx);

            boolean over = mouseX >= x && mouseX < x + SLOT && mouseY >= y && mouseY < y + SLOT;
            if (over) {
                ctx.fill(x, y, x + SLOT, y + SLOT, 0x80FFFFFF);
                hovered = stack;
            }
            ctx.drawItem(stack, x + 1, y + 1);
        }

        // Панель зачарований
        ctx.drawTextWithShadow(textRenderer, Text.translatable("cheatinv.enchants"), enchX, searchY + 4, 0xFFFFFF);
        for (int i = 0; i < visibleEnchRows(); i++) {
            int idx = enchScroll + i;
            if (idx >= enchants.size()) break;
            Ench e = enchants.get(idx);
            int y = gridY + i * ROW_H;
            int lv = enchLevels.getOrDefault(e.id(), 0);

            boolean over = mouseX >= enchX && mouseX < enchX + ENCH_W && mouseY >= y && mouseY < y + ROW_H;
            if (over) ctx.fill(enchX, y, enchX + ENCH_W, y + ROW_H, 0x40FFFFFF);

            int color = lv == 0 ? 0x888888 : (lv > e.max() ? 0xFFAA00 : 0x55FF55);
            String name = textRenderer.trimToWidth(e.name().getString(), ENCH_W - 40);
            ctx.drawTextWithShadow(textRenderer, name, enchX + 3, y + 2, color);
            String lvStr = lv + "/" + e.max();
            ctx.drawTextWithShadow(textRenderer, lvStr, enchX + ENCH_W - textRenderer.getWidth(lvStr) - 3, y + 2, color);
        }

        // Подсказки внизу
        int hintY = gridY + ROWS * SLOT + 5;
        ctx.drawCenteredTextWithShadow(textRenderer, Text.translatable("cheatinv.hint.items"), width / 2, hintY, 0xAAAAAA);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.translatable("cheatinv.hint.enchants"), width / 2, hintY + 11, 0xAAAAAA);

        // Всплывающие подсказки
        if (hovered != null) {
            ctx.drawItemTooltip(textRenderer, buildStack(hovered, 1), mouseX, mouseY);
        } else if (tabTooltip != null) {
            ctx.drawTooltip(textRenderer, tabTooltip, mouseX, mouseY);
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        if (vertical != 0) {
            int dir = (int) Math.signum(vertical);
            if (mouseX >= enchX && mouseX < enchX + ENCH_W) {
                enchScroll = Math.max(0, Math.min(maxEnchScroll(), enchScroll - dir));
            } else {
                scrollRow = Math.max(0, Math.min(maxScroll(), scrollRow - dir));
            }
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontal, vertical);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) return true;

        // Вкладки
        for (int i = 0; i < tabs.size(); i++) {
            int x = left + (i % tabsPerRow) * TAB_W;
            int y = tabsY + (i / tabsPerRow) * TAB_H;
            if (mouseX >= x && mouseX < x + TAB_W - 1 && mouseY >= y && mouseY < y + TAB_H - 1) {
                currentTab = i;
                lastTab = i;
                scrollRow = 0;
                applyFilter();
                return true;
            }
        }

        // Сетка предметов
        if (mouseX >= left && mouseX < left + COLS * SLOT && mouseY >= gridY && mouseY < gridY + ROWS * SLOT) {
            int col = (int) ((mouseX - left) / SLOT);
            int row = (int) ((mouseY - gridY) / SLOT);
            int idx = (scrollRow + row) * COLS + col;
            if (idx >= 0 && idx < filtered.size()) {
                ItemStack base = filtered.get(idx);
                boolean full = hasShiftDown() || button == 1;
                int count = full ? base.getMaxCount() : 1;
                ClientPlayNetworking.send(new GiveStackPayload(buildStack(base, count)));
                return true;
            }
        }

        // Список зачарований: ЛКМ +, ПКМ -, колёсико = максимум, Shift = шаг 10
        if (mouseX >= enchX && mouseX < enchX + ENCH_W && mouseY >= gridY && mouseY < gridY + ROWS * SLOT) {
            int row = (int) ((mouseY - gridY) / ROW_H);
            int idx = enchScroll + row;
            if (row < visibleEnchRows() && idx >= 0 && idx < enchants.size()) {
                Ench e = enchants.get(idx);
                int lv = enchLevels.getOrDefault(e.id(), 0);
                int step = hasShiftDown() ? 10 : 1;
                if (button == 0) lv += step;
                else if (button == 1) lv -= step;
                else if (button == 2) lv = (lv == e.max()) ? 0 : e.max();
                lv = Math.max(0, Math.min(255, lv));
                if (lv == 0) enchLevels.remove(e.id());
                else enchLevels.put(e.id(), lv);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
